## RCON-alike mod that allows you to control your server from Web without need of opening port.


### Control Site (instruction left top corner): https://kg-dev.xyz/servercontrol/


<details><summary>Screenshots</summary>

![](https://i.imgur.com/IPBcqE4.png)
![](https://i.imgur.com/tQWP3kx.png)
![](https://i.imgur.com/sxOjsUR.png)
</details>


For Questions or Comments, find KG in the Odin
Plus Discord:
[![https://i.imgur.com/XXP6HCU.png](https://i.imgur.com/XXP6HCU.png)](https://discord.gg/5gXNxNkUBt)

 